import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../Student';
import { FormGroup,FormControl } from '@angular/forms';


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
 //obj:Student=new Student(0,"","","","");
  //Student:Student= new Student(2,"Ancy","fhfcgj","7876656789","MCA");

  constructor(private student:StudentService) { }

  addStudent = new FormGroup({
    //Id: new FormControl( '' ),
    Name: new FormControl( '' ),
    Address: new FormControl( '' ),
    Phone: new FormControl( '' ),
    Course: new FormControl( '' )

  });

  ngOnInit(): void {
  }
  SaveStudent(){
   // console.log(this.addStudent.value);
    this.student.AddStudent(this.addStudent.value).subscribe((obj)=>{
     // console.log( obj );
    });
    
  }
   // this.StudentService.AddStudent(this.obj)
     //this.Student=new Student(0,"","","","")
   // .subscribe(
    // data=>{alert("Student data inserted")},error=>{alert(JSON.stringify(error))}
    //);
  //}

}
