import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Student} from './Student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

 //readonly url = 'http://localhost:2956/api/Student'

  constructor(private client:HttpClient) { }

 GetStudent():Observable<Array<Student>>{
  return  this.client.get<Array<Student>>("http://localhost:2956/api/Student");
}
//AddStudent(obj:any){
  //console.log(obj);
  //return this.client.post(this.url,obj);

  AddStudent(obj:Student):Observable<any>{
    return this.client.post("http://localhost:2956/api/Student",obj)   
}
DeleteStudent(id:number):Observable<any>{
  return this.client.delete<Array<Student>>("http://localhost:2956/api/Student/" +id )
}
}
