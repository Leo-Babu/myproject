import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../Student';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  Student:Array<Student>;
  constructor(private service:StudentService) { 
    this.service.GetStudent().subscribe(
      (result)=>{this.Student=result;},
      (error)=>{alert(JSON.stringify(error))}
    );
  }

  ngOnInit(): void {
  }
  DeleteStudent(id: any) {
    this.service.DeleteStudent(id).subscribe(
      (data) => { alert("Deleted Successfull"); 
        //this.ornaments.splice(this.ornaments.indexOf(id),1);
        this.Student.forEach((item, index, object) => {
          if (item.Id === id) {
            object.splice(index, 1);
          }
        })
      },
      (error) => { alert(JSON.stringify(error)) }
    );
}

}

