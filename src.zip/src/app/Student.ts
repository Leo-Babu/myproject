export class Student{
    constructor (public Id:Number,  public Name:string, public Address:string, public Phone:string, public Course:string){
       
        this.Id=Id;
        this.Name=Name;
        this.Address=Address;
        this.Phone=Phone;
        this.Course=Course;
       
    }
  }